
const logCallToGoogleSheets = async (data) => {
  console.log('Logging call to Google Sheets:', data);
  return true;
};

module.exports = { logCallToGoogleSheets };
