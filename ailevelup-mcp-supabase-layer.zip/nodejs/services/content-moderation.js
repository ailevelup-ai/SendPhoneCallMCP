
const moderateContent = async (content) => {
  return { isAllowed: true, reason: null };
};

module.exports = { moderateContent };
